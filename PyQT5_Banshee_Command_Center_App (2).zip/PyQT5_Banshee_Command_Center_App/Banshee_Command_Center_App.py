
import time
from turtle import mode
from PyQt5 import QtCore
from PyQt5.uic import loadUi
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import sys
import pandas as pd
import time
import folium
import streamlit as st
import os
from streamlit_folium import st_folium

from PyQt5 import QtCore, QtGui ,QtWidgets 
from PyQt5.QtWidgets import QApplication, QMessageBox, QWidget, QHBoxLayout, QVBoxLayout, QSizePolicy, QGridLayout , QLineEdit, QLabel ,QPushButton 
from PyQt5.QtWebEngineWidgets import QWebEngineView 
import io, folium
import qdarktheme
import cv2
from traitlets import default

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
import numpy as np
import random
import threading
import time

from PIL import Image
 

global calibrate_drone_direction  # north
global compass_prev_direction
global battery_prev_direction
global Roll_prev_direction

calibrate_drone_direction = 0  # north
compass_prev_direction = calibrate_drone_direction
battery_prev_direction = 0
Roll_prev_direction = 0

class RadarPlotWidget(QWidget):
    """
    Widget displaying a compass plot with a red data point.
    """

    def RadarPlotWidget_init_(self, parent=None):
        """
        Initializes the widget and creates the compass plot.
        """
        super(RadarPlotWidget, self).__init__(parent)

        # Create layout
        layout = QVBoxLayout(self)

        # Configure plot
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})

        # Define data
        theta = 90  # Compass bearing in degrees
        theta = 360 - theta - 180

        # Add data point
        ax.plot(np.radians(theta), 7, marker='s', markersize=15, markerfacecolor='red', zorder=2)

        # Set axis limits and ticks
        ax.set_rmax(12)  # Adjusted the maximum radial limit
        ax.set_rticks([1, 3, 6, 9, 12])
        ax.set_rlabel_position(-22.5)
        ax.set_theta_zero_location('N')
        ax.set_theta_direction(-1)

        # Enable grid and adjust appearance
        ax.grid(True, linestyle='--', alpha=0.7, zorder=0)

        # Set title and labels
        ax.set_title("Compass Plot with Distance Ticks", va='bottom')
        ax.set_xlabel('Compass Bearing')
        ax.set_ylabel('Distance (m)')

        # Set background color to dark green
        ax.set_facecolor('darkgreen')

        # Create graphics scene
        scene = QGraphicsScene(self)

        # Initialize FigureCanvas with fig
        canvas = FigureCanvas(fig)
        canvas.draw()
        pixmap = canvas.grab()

        # Add pixmap to graphics scene
        scene_item = scene.addPixmap(pixmap)

        # Create graphics view
        view = QGraphicsView(scene)

        # Add widgets to layout
        layout.addWidget(view)

        # Set layout
        self.setLayout(layout)




class Cal_compass_Dialog_window_CLASS(QDialog):
    def __init__(self, *args, **Kwargs):
        super(Cal_compass_Dialog_window_CLASS, self).__init__(*args, **Kwargs)
        loadUi('Cal_compass_window.ui',self)
        self.setWindowIcon(QIcon('Banshee_logo.png'))
        self.setWindowTitle('Calibraion of Compass')
        self.setWindowOpacity(0.91)
        
        # define and find child name in ui file
        self.CAL_Compass_Cancel_btn = self.findChild(QPushButton,'CAL_Compass_Cancel_btn')
        self.CAL_Compass_ok_btn = self.findChild(QPushButton,'CAL_Compass_ok_btn')
        self.CAL_Compass_text_box_input = self.findChild(QLineEdit,'CAL_Compass_angle_txtBox')
        # btn control
        self.CAL_Compass_Cancel_btn.clicked.connect(self.CAL_Compass_Cancel_fuction) 
        self.CAL_Compass_ok_btn.clicked.connect(self.CAL_Compass_ok_fuction) 
    
    def CAL_Compass_Cancel_fuction(self):
        print('Cancel was pressed')
        self.reject()

    def CAL_Compass_ok_fuction(self):
        print('ok was pressed')
        try:
            cal_data = float(self.CAL_Compass_text_box_input.text())
            Calibrate_Compass_data_correction(cal_data)
            self.accept()
        except:
            pass
         

class MainWindow(QMainWindow):

    def __init__(self, *args, **Kwargs):
        super(MainWindow, self).__init__(*args, **Kwargs)
        loadUi('GUI_Banshee_Command_Center.ui',self)
        self.setWindowIcon(QIcon('Banshee_logo.png'))
        self.setWindowTitle('Banshee Command Center')
        self.setWindowOpacity(0.95)
        # define and find child name in ui file
        self.video_feed_label = self.findChild(QLabel,'RGB_video_feed')
        self.map_viewer = self.findChild(QWebEngineView,'map')
        self.btn_add_marker = self.findChild(QPushButton, "add_marker_btn")
        self.txt_latitude_input = self.findChild(QLineEdit,'latitude_input_TextBox')
        self.txt_longitude_input = self.findChild(QLineEdit,'longitude_input_TextBox')
        self.txt_name_add_marker = self.findChild(QLineEdit, 'name_add_maker')
        self.txt_description_add_marker = self.findChild(QLineEdit, 'description_input_text_box')
        self.compass_graphicsView = self.findChild(QGraphicsView, 'compass_graphicsView')
        self.Calibrate_Compass_Btn = self.findChild(QPushButton, 'Calibrate_Compass')
        self.compass_view_text = self.findChild(QLabel,'compass_view')
        self.drone_data_listWidgets = self.findChild(QListWidget, 'drone_data_listWidgets')
        self.drone_data_name_textBox = self.findChild(QLabel,'Drone_name_header_txt')
        # QpushButton Controls
        self.btn_add_marker.clicked.connect(self.add_maker)
        self.Calibrate_Compass_Btn.clicked.connect(self.open_CAL_Compass_window)

   
        # - Drone info
        font = self.drone_data_listWidgets.font()
        font.setPointSize(12)  # Change the font size to 12 points
        font.setBold(True)  # Make the font bold
        self.drone_data_listWidgets.setFont(font)
        self.drone_live_data()
 
       
        # Set the map data to the webview
        coordinate = (34.0555, -117.8088)
        marker_coordinate = (33.0555, -119.8088)
        self.bcc_map = folium.Map(location=coordinate, zoom_start=4  )
        folium.Marker(location=marker_coordinate).add_to(self.bcc_map)
        self.update_map()

        # compass 
        self.compass_app()

        self.Roll_Level_gauge()

        self.battery_life_gauge()
        #print('testsetsets')

        # Set up a timer to update the video frame periodically
        self.cap = cv2.VideoCapture(0)
        self.timer = QtCore.QTimer()
        self.timer.setInterval(20)  # Update frame every 20 milliseconds
        self.timer.timeout.connect(self.update)
        self.timer.start()


    def update(self):
        ret, frame = self.cap.read()
        rgbFrame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        rgbFrame = cv2.resize(rgbFrame,(1080,1080))
        h, w, ch = rgbFrame.shape
        bytesPerLine = ch * w
        convertToQtFormat = QtGui.QImage(rgbFrame.data, w, h, bytesPerLine, QtGui.QImage.Format_RGB888)
        pixmap = QtGui.QPixmap(convertToQtFormat)
        self.video_feed_label.setPixmap(pixmap)

        #update_battery_gauge
        self.battery_update(self.Live_entries_data[9])

        #update compass
        self.compass_app()
    
        self.Roll_Level_gauge()


    def drone_live_data(self):

        self.default_entries_names = [
            'Drone Name',
            'Date',
            'Time' ,
            'GPS Status',
            'GPS_Fix',
            'GPS_Count',
            'Battery State',
            'Battery Voltage',
            'Battery Current',
            'Battery Level',
            'Armable']
        
        self.default_entries_data_NA = [
            'N/A ',
            'N/A ',
            'N/A ' ,
            'N/A ',
            'N/A ',
            'N/A ',
            'N/A ',
            'N/A ',
            'N/A ',
            'N/A' ,
            'N/A' ]

        self.Presented_data = []
        # Get the current working directory
        old_directory = os.getcwd()

        # Change the working directory
        os.chdir(r'C:\Users\cmatc\source\repos\Banshee_DroneKIT_testing')

        # Read the last row of the CSV file
        csv_filename = 'Drone-data.csv'
        last_row = self.read_last_row(csv_filename)

        # Update the data based on the last row
        if last_row:
            default_entries_data = list(last_row.values())
            
            data_Name = 'Brody'
            data_Date = default_entries_data[0]
            data_Time = default_entries_data[1]
            data_GPS_fix, data_GPS_count = DroneINFO_parse_Equal(default_entries_data[2])
            data_Battery_voltage, data_Battery_Current, data_Battery_Level = DroneINFO_parse_Equal(default_entries_data[3])
            data_Armable = default_entries_data[4]
            data_Battery_Status = default_entries_data[5]
            data_GPS_Status = default_entries_data[6]

            self.Live_entries_data = [data_Name,         # 0
                                 data_Date,              # 1 
                                 data_Time,              # 2 
                                 data_GPS_Status,        # 3  
                                 data_GPS_fix,           # 4  
                                 data_GPS_count,         # 5    
                                 data_Battery_Status,    # 6  
                                 data_Battery_voltage,   # 7  
                                 data_Battery_Current,   # 8  
                                 data_Battery_Level,     # 9 
                                 data_Armable]           # 10   
            self.Presented_data = self.Live_entries_data
        else:
            self.Presented_data = self.default_entries_data_NA
        # display onto window and drone_data_listWidgets
        self.drone_data_listWidgets.setWindowTitle('Drone Status')

        for i in range(len(self.default_entries_names)):
            #temp_drone_data  = f'{default_entries_names[i]}:   {Presented_data[i]}'
            temp_drone_data = f"{self.default_entries_names[i]:<15}   = {self.Presented_data[i]:<8}"
            
            self.drone_data_listWidgets.addItem(temp_drone_data)
            
             

        # Change back to the original working directory
        os.chdir(old_directory)
        

        self.drone_data_name_textBox.setText(f"Drone: {self.Live_entries_data[0]}")


    def read_last_row(self, csv_filename):
        try:
            df = pd.read_csv(csv_filename)
            last_row = df.iloc[-1].to_dict()
            return last_row
        except pd.errors.EmptyDataError:
            return None



    def Roll_Level_gauge(self):
            Roll_scene_bottomLayer = QGraphicsScene()
            Roll_scene_topLayer = QGraphicsScene()
            Roll_scene_top_top_Layer = QGraphicsScene()

                
            gauge_pix = QPixmap("blueGauge.png")
            gauge_pix=gauge_pix.scaled(220,220)
            gauge_pix = QGraphicsPixmapItem(gauge_pix)

            Roll_icon_gauge_pix = QPixmap("battery-icon-32.png")


            #battery_icon_gauge_pix = change_image_color(battery_icon_gauge_pix)
            
            Roll_icon_gauge_pix=Roll_icon_gauge_pix.scaled(50,50)
            Roll_icon_gauge_pix = QGraphicsPixmapItem(Roll_icon_gauge_pix)
        
            Roll_arrow_pointer_pix = QPixmap("needle.png")
            Roll_arrow_pointer_pix = Roll_arrow_pointer_pix.scaled(270,270)
            Roll_arrow_pointer_item =QGraphicsPixmapItem(Roll_arrow_pointer_pix)

            Roll_scene_top_top_Layer.addItem(Roll_icon_gauge_pix)
            Roll_scene_bottomLayer.addItem(gauge_pix)
            Roll_scene_topLayer.addItem(Roll_arrow_pointer_item)

            
            self.Roll_view_bottomLayer = QGraphicsView(Roll_scene_bottomLayer,self)
            self.Roll_view_top_ROLL_DRONE_icon = QGraphicsView(Roll_scene_top_top_Layer,self)
            self.Roll_view_top = QGraphicsView(Roll_scene_topLayer,self)


            self.Roll_view_top_ROLL_DRONE_icon.setStyleSheet("background:transparent;")
            self.Roll_view_bottomLayer.setStyleSheet("background:transparent;")
            self.Roll_view_top.setStyleSheet("background:transparent;")
            self.Roll_view_top.setFrameShape(QFrame.NoFrame)
            self.Roll_view_bottomLayer.setFrameShape(QFrame.NoFrame)
            self.Roll_view_top_ROLL_DRONE_icon.setFrameShape(QFrame.NoFrame)
            self.Roll_view_bottomLayer.setGeometry(3020,1420, 250,250)
            self.Roll_view_top.setGeometry(3020,1420, 300,300)
            self.Roll_view_top_ROLL_DRONE_icon.setGeometry(3020,1420, 150,171)
            self.Roll_LEVEL_update(self.Live_entries_data[9])
            #print(self.Live_entries_data[9])


    def Roll_LEVEL_update(self, input ):

        temp = input
        #print(temp)
        try:
            temp_float = float(temp)
    
            temp_RotDeg = self.Roll_LEVEL_POStoRotationalDegrees(temp_float)
            #print(temp_RotDeg)
            self.Roll_view_top.rotate(temp_RotDeg)
        except:
                pass
        
    def Roll_LEVEL_POStoRotationalDegrees(self,input_):
        if(input_ > 0 and input_ < 100.1):
            global Roll_prev_direction
            input_ = map(input_ , 0,100,0,180)
            angle =  Roll_prev_direction - input_ 
            Roll_prev_direction = input_
            return angle *-1
        else:
            return 0

 

    def battery_life_gauge(self):
        battery_scene_bottomLayer = QGraphicsScene()
        battery_scene_topLayer = QGraphicsScene()
        battery_scene_top_top_Layer = QGraphicsScene()

              
        gauge_pix = QPixmap("blueGauge.png")
        gauge_pix=gauge_pix.scaled(220,220)
        gauge_pix = QGraphicsPixmapItem(gauge_pix)

        battery_icon_gauge_pix = QPixmap("battery-icon-32.png")

        
        #battery_icon_gauge_pix = change_image_color(battery_icon_gauge_pix)
        
        battery_icon_gauge_pix=battery_icon_gauge_pix.scaled(50,50)
        battery_icon_gauge_pix = QGraphicsPixmapItem(battery_icon_gauge_pix)
    
        battery_arrow_pointer_pix = QPixmap("needle.png")
        battery_arrow_pointer_pix = battery_arrow_pointer_pix.scaled(270,270)
        battery_arrow_pointer_item =QGraphicsPixmapItem(battery_arrow_pointer_pix)

        battery_scene_top_top_Layer.addItem(battery_icon_gauge_pix)
        battery_scene_bottomLayer.addItem(gauge_pix)
        battery_scene_topLayer.addItem(battery_arrow_pointer_item)

        
        self.battery_view_bottomLayer = QGraphicsView(battery_scene_bottomLayer,self)
        self.battery_view_top_battery_icon = QGraphicsView(battery_scene_top_top_Layer,self)
        self.battery_view_top = QGraphicsView(battery_scene_topLayer,self)


        self.battery_view_top_battery_icon.setStyleSheet("background:transparent;")
        self.battery_view_bottomLayer.setStyleSheet("background:transparent;")
        self.battery_view_top.setStyleSheet("background:transparent;")
        self.battery_view_top.setFrameShape(QFrame.NoFrame)
        self.battery_view_bottomLayer.setFrameShape(QFrame.NoFrame)
        self.battery_view_top_battery_icon.setFrameShape(QFrame.NoFrame)
        self.battery_view_bottomLayer.setGeometry(3060,1140, 250,250)
        self.battery_view_top.setGeometry(3037,1163, 300,300)
        self.battery_view_top_battery_icon.setGeometry(3110,1170, 150,171)
        self.battery_update(self.Live_entries_data[9])
        #print(self.Live_entries_data[9])


    def battery_update(self, input ):

        temp = input
        #print(temp)
        try:
            temp_float = float(temp)
    
            temp_RotDeg = self.battery_POStoRotationalDegrees(temp_float)
            #print(temp_RotDeg)
            self.battery_view_top.rotate(temp_RotDeg)
        except:
                pass
        
    def battery_POStoRotationalDegrees(self,input_):
        if(input_ > 0 and input_ < 100.1):
            global battery_prev_direction
            input_ = map(input_ , 0,100,0,180)
            angle =  battery_prev_direction - input_ 
            battery_prev_direction = input_
            return angle *-1
        else:
            return 0


    def compass_app(self):
        scene_bottomLayer = QGraphicsScene()
        scene_topLayer = QGraphicsScene()
              
        arrow_pix = QPixmap("blank_compass.png")
        
        arrow_pix=arrow_pix.scaled(300,300)
        arrow_item = QGraphicsPixmapItem(arrow_pix)
    
        arrow_pointer_pix = QPixmap("R.png")
        arrow_pointer_pix = arrow_pointer_pix.scaled(300,300)
        arrow_pointer_item =QGraphicsPixmapItem(arrow_pointer_pix)


        scene_bottomLayer.addItem(arrow_item)
        scene_topLayer.addItem(arrow_pointer_item)

        
        self.view_bottomLayer = QGraphicsView(scene_bottomLayer,self)
        self.view_bottomLayer.setStyleSheet("background:transparent;")
        self.view_top = QGraphicsView(scene_topLayer,self)
        self.view_top.setStyleSheet("background:transparent;")
        self.view_top.setFrameShape(QFrame.NoFrame)
        self.view_bottomLayer.setFrameShape(QFrame.NoFrame)
        self.view_bottomLayer.setGeometry(3220,1120, 511,431)
        self.view_top.setGeometry(3220,1120, 511,431)
        try:
            self.update_compass(80)
        except:
            pass
        

    def update_compass(self, input):
        temp = input
        #print(temp)
        try:
            temp_float = float(temp)
            temp_RotDeg = self.compassPOStoRotationalDegrees(temp_float)
            #print(temp_RotDeg)
            self.view_top.rotate(temp_RotDeg)
        except:
                pass
        
    def compassPOStoRotationalDegrees(self,input_direction):
        global compass_prev_direction
        direction = round(input_direction,1)
        angle = compass_prev_direction - direction 
        #print(angle)
        compass_prev_direction = direction
        return angle

    def open_CAL_Compass_window(self):
        self.CAL_Compass_window_ui = Cal_compass_Dialog_window_CLASS() 
        self.CAL_Compass_window_ui.exec_()
        
 

    def add_maker(self):
        #self.txt_latitude_input = self.findChild(QLineEdit,'latitude_input_TextBox')
        #self.txt_longitude_input = self.findChild(QLineEdit,'longitude_input_TextBox')
        #self.txt_name_add_marker = self.findChild(QLineEdit, 'name_add_maker')
        #self.txt_description_add_marker = self.findChild(QTextEdit, 'description_add_marker')
        temp_name = self.txt_name_add_marker.text()
        temp_description = self.txt_description_add_marker.text()
        temp_latitude = self.txt_latitude_input.text()
        temp_longitude = self.txt_longitude_input.text()
        try:
            temp_marker_coordinate = (float(temp_latitude),float(temp_longitude))
            temp_description= str(str(temp_marker_coordinate) +" - " +temp_description)

            folium.Marker(location=temp_marker_coordinate, popup=temp_description, tooltip=temp_name).add_to(self.bcc_map)
            self.update_map()
       
            self.txt_latitude_input.clear()
            self.txt_longitude_input.clear() 
            self.txt_name_add_marker.clear()
            self.txt_description_add_marker.clear()
        except:
            print('Error - Clearing Text Input Dialog... ')
            self.txt_latitude_input.clear()
            self.txt_longitude_input.clear() 
            self.txt_name_add_marker.clear()
            self.txt_description_add_marker.clear()
            

    def update_map(self):
        data = io.BytesIO()
        self.bcc_map.save(data, close_file=False)
        self.map_viewer.setHtml(data.getvalue().decode())
 
 
def DroneINFO_parse_Equal(input_string):
  found_equals = []
  numbers_data = []
  # to find at the index is the '='
  temp_list = list(input_string)
  for i in range(len(temp_list)):
    if temp_list[i] == '=':
      found_equals.append(i)
  # to find the numbers with in the dronekit info format
  for equals in range(len(found_equals)):
    temp_data_output = DroneINFO_intParser(temp_list,'',found_equals[equals])
    numbers_data.append(temp_data_output)
  # numbers to floats
  for i in range(len(numbers_data)):
    numbers_data[i] = float(numbers_data[i])

  return numbers_data
 

def DroneINFO_intParser(temp_list,num,i):
    if temp_list[i] == '=':
      for z in range(i + 1, len(temp_list)):
        if (temp_list[z]== ',' or i == len(temp_list)-1):
          break
        else:
          num = num + temp_list[z]

    return num


def Calibrate_Compass_data_correction(input_data):
    global compass_prev_direction
    compass_prev_direction = input_data
    #MainWindow.update_compass(MainWindow,compass_prev_direction)
    print('update to compass_prev_direction')


def map(value, fromLow, fromHigh, toLow, toHigh):
    normalizedValue = (value - fromLow) / (fromHigh - fromLow)
    return toLow + normalizedValue * (toHigh - toLow)



def change_color(image_path, target_color, replacement_color):
    # Open the image
    img = Image.open(image_path)

    # Convert the image to a NumPy array
    img_array = np.array(img)

    # Define the target color (RGB format)
    target_color = tuple(target_color)

    # Create a mask of pixels that match the target color
    mask = np.all(img_array[:, :, :3] == target_color, axis=-1)

    # Replace the target color with the replacement color
    img_array[mask, :3] = replacement_color

    # Convert the NumPy array back to an image
    new_img = Image.fromarray(img_array)

    return new_img
    # Save the modified image
    ##new_img.save(output_path)
    ####  change_color(icon_path, target_color, replacement_color, output_path)



 
def main():
    app = QApplication(sys.argv)
    qdarktheme.setup_theme()
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()